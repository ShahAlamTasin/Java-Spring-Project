package com.example.demo.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.model.Student;
import com.example.demo.service.StudentService;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;

@EnableAutoConfiguration
@Controller
//this class is responsible for control the get and post request from different html file
public class StudentController {

	@Autowired
	private StudentService studentservice;
	// display list of Students

	@GetMapping("/")
	public String ViewHomePage(Model model) {
		//responsible for handle the  request to fetch all table data
		model.addAttribute("liststudents", studentservice.getAllStudents());
		return "index";
	}

	@GetMapping("/showNewEmployeeForm")
	public String showNewEmployeeForm(Model model) {
		//responsible for handle the  request to go new page for add student
		Student student = new Student();
		model.addAttribute("student", student);
		return "new_student";
	}

	@PostMapping("/saveStudent")
	public String saveStudent(@Valid @ModelAttribute("student") Student student) {
		//responsible for handle the  request to save the given data to the student table
		studentservice.saveStudent(student);

		return "redirect:/";

	}

	@GetMapping("/showFormForUpdate/{id}")
	public String showFormForUpdate(@PathVariable(value = "id") Integer id, Model model) {
		//responsible for handle the  request to fetch  value for {id} and save the updated value to the table
		Student student = studentservice.getStudentById(id);

		model.addAttribute("student", student);
		return "update_student";
	}

	@GetMapping("/deleteStudent/{id}")

	public String deleteStudent(@PathVariable(value = "id") Integer id) {
		//responsible for handle the  request to delete the  value for {id}
		this.studentservice.deleteStudentById(id);
		return "redirect:/";
	}

}
