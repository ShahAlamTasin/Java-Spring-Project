package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Student;

import com.example.demo.service.StudentService;

//this class is responsible for creating REST API to get student list
@RestController
@RequestMapping("/api/v1/students")
public class StudentApiController {

	@Autowired
	private StudentService studentservice;

	@GetMapping("/")
	public List<Student> getCustomers() {
		return studentservice.getAllStudents();
	}

	@PostMapping("/")
	public void addUser(@RequestBody Student userRecord) {

		studentservice.saveStudent(userRecord);

	}
}
