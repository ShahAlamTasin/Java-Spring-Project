package com.example.demo.service;

import java.util.List;

import com.example.demo.model.Student;
//interface that contains different method for perform different operation 
public interface StudentService {

	List<Student> getAllStudents();

	public void saveStudent(Student student);

	Student getStudentById(Integer id);

	void deleteStudentById(Integer id);
}
