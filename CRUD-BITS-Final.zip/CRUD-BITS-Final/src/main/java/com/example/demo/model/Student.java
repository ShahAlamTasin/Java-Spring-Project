package com.example.demo.model;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
//this class is responsible for creating the student table in the mysql server
@Entity
@Table(name = "studentdata")
public class Student {
//id is the primary key
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	@Column(nullable = false, length = 45)
	private String name;

	@Column(nullable = false)
	@NotBlank(message = "Birthdate is mandatory")
	private String birthdate;

	@Column(nullable = false)

	@NotBlank(message = "gender is mandatory")
	private String gender;

	
	private String note;

	@Column(nullable = false, length = 20)
	@NotBlank(message = "passward is mandatory")
	private String pass;
 // getter setter method for acces the private values
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getBirthdate() {
		return birthdate;
	}

	public void setBirthdate(String birthdate) {
		this.birthdate = birthdate;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

}
