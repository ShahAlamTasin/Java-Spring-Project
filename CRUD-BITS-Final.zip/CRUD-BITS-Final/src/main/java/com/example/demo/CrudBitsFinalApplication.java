package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
//@EntityScan( basePackages = {"uniroma3.siw.model"} )
public class CrudBitsFinalApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudBitsFinalApplication.class, args);
	}

}
